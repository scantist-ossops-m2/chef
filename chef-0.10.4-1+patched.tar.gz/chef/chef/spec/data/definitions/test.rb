define :rico_suave, :rich => "smooth" do
  zen_master "test" do
    something "#{params[:rich]}"
  end
end