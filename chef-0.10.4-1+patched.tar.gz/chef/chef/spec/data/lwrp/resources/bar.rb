actions :pass_buck, :prepare_eyes, :watch_paint_dry
