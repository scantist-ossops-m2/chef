actions :never_execute

attribute :ever, :kind_of => String
