cat "peanut" do
  pretty_kitty true
end

new_cat "fat peanut" do
  pretty_kitty false
end
