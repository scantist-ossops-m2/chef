cat "blanket" do
  pretty_kitty true
end
