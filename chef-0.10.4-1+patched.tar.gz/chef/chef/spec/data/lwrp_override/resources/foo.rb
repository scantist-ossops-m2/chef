actions :pass_buck, :prepare_thumbs, :twiddle_thumbs

attribute :monkey, :kind_of => String
