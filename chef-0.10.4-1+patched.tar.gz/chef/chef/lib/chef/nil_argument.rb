class Chef
  NIL_ARGUMENT = Object.new
end
