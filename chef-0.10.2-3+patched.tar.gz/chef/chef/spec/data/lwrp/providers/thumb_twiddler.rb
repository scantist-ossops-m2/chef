action :prepare_thumbs do
  "Prepared"
end

action :twiddle_thumbs do
  "Twiddle twiddle"
end
