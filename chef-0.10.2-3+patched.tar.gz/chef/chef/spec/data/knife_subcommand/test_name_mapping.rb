module KnifeSpecs
  class TestNameMapping < Chef::Knife
  end  
end
