cat "loulou" do
  pretty_kitty true
end

new_cat "birthday" do
  pretty_kitty false
end
