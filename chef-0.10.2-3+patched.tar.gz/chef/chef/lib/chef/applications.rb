require 'chef/application/agent'
require 'chef/application/client'
require 'chef/application/knife'
require 'chef/application/solo'
